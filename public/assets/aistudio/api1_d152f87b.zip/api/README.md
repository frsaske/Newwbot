# DeepSeek Free API

Ready-to-use local OpenAI-compatible API & Web Chat Interface for DeepSeek.

## Credentials Configured (`.env`)
- `PORT`: 8000
- `HOST`: 0.0.0.0
- `DS_SESSION_ID`: `e671f613-4863-4850-9ca3-498584a78b61`
- `DEEP_SEEK_CHAT_AUTHORIZATION`: `/tvrK/FNL+5A8GhdkmXkzOzcrHg3TuPdW6duaTv/FMSJ9iP+qqjbtys9+yErmLh6`

## How to Run

### 1. Start Server
```bash
cd /workspace/api
npm start
```
Server runs at `http://localhost:8000`

### 2. Web Chat Interface
Open `http://localhost:8000` in any web browser.

### 3. Interactive Terminal Chat
```bash
cd /workspace/api
node chat.js
```

### 4. Direct API Request (cURL)
```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-chat",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```
