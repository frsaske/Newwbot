#!/usr/bin/env node

import readline from "readline";

const API_URL = "http://localhost:8000/v1/chat/completions";
const MODEL = "deepseek-chat";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const messages = [];

console.log("\x1b[36m========================================\x1b[0m");
console.log("\x1b[32m🚀 DeepSeek Free Terminal Chat CLI\x1b[0m");
console.log("\x1b[90mType your question, press Enter. Type 'exit' to quit.\x1b[0m");
console.log("\x1b[36m========================================\x1b[0m\n");

function prompt() {
  rl.question("\x1b[33mUser > \x1b[0m", async (input) => {
    const text = input.trim();
    if (!text) return prompt();
    if (text.toLowerCase() === "exit" || text.toLowerCase() === "quit") {
      console.log("\nBye!");
      process.exit(0);
    }

    messages.push({ role: "user", content: text });
    process.stdout.write("\x1b[35mDeepSeek > \x1b[0mThinking...");

    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: MODEL,
          messages: messages,
        }),
      });

      const data = await res.json();
      readline.clearLine(process.stdout, 0);
      readline.cursorTo(process.stdout, 0);

      const reply = data.choices?.[0]?.message?.content || JSON.stringify(data);
      console.log(`\x1b[32mDeepSeek >\x1b[0m ${reply}\n`);
      messages.push({ role: "assistant", content: reply });
    } catch (err) {
      readline.clearLine(process.stdout, 0);
      readline.cursorTo(process.stdout, 0);
      console.error(`\x1b[31mError:\x1b[0m ${err.message}\n`);
    }

    prompt();
  });
}

prompt();
